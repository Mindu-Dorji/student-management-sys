const express = require('express');
const mongoose = require('mongoose');

const studentsRouter = require('./routes/students');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/students", studentsRouter);

const start = async () => {
    const mongoURI = "mongodb://localhost:27017";

    try{
        await mongoose.connect(mongoURI, {
            useNewUrlParser: true });

            app.listen(3000, () => console.log('Server started'));
     }
      catch (error)
        {
         console.log("Error starting Server", error);
         }
        
};

start();







