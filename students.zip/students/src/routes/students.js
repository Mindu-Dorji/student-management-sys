const express = require('express');
const Mongoose = require('mongoose');
const  {body, validationResult} = require('express-validator');
const { restart } = require('nodemon');
const app = express.Router();
const Students = require('../models/students');

const studentsRouter = require('./students');
var cors = require('cors');


app.use(cors());

app.get('/', async (req, res) => {
    try {
        const allStudents = await Students.find({});
        res.send(allStudents);
    }
    catch (error) {
        console.log("Error", error);
        res.status(500).sendStatus("Error creating Students");
    }
});
app.get('/:id', async (req, res) => {
    const id = req.params.id;
    if(!Mongoose.Types.ObjectId.isValid(id)) {
       return res.status(400).send('Invalid ID');
    }
    
    try {
        const students = await students.findById(id);
     
       if (students) {
            res.send(students);
        }
        else {
            res.status(404).send('Student not found');
        }
       
    }
    catch (error) {
        console.log ("ERROR", error);
        res.status(500).sendStatus("Error getting students");
    }
});

app.post('/', 
body('name').isString().isLength({ min: 4, max: 20 }).withMessage("value for name is not valid"),
async(req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
        return res.status(400).send(errors);
    }
    //console.log(req.body);
    const students= new Students(req.body);

    try {
       const newStudents = await students.save()
       res.send(newStudents);
    }
    catch (error) {
        console.log("Error", error);
        res.status(500).sendStatus("Error creating Student");
    }
});

app.put('/:id', async (req, res) => {
    const id = req.params.id;
    if(!Mongoose.Types.ObjectId.isValid(id)) {
       return res.status(400).send('Invalid ID');
    }
    try {
        const students = await students.findByIdAndUpdate(id, req.body, { new: true });
        if (students) {
            res.send(students);
        }
        else {
            res.status(404).send('Student not found');
        }
        //console.log(students);
       // res.send(students);
    }
    catch (error) {
        console.log ("ERROR", error);
        res.status(500).sendStatus("Error Updating students");
    }
    
});

app.delete('/:id', async (req, res) => {
    const id = req.params.id;
    if(!Mongoose.Types.ObjectId.isValid(id)) {
       return res.status(400).send('Invalid ID');
    }
    
    try{
        const students = await Students.findByIdAndDelete(id);
        if (students) {
            res.send(students);
        }
        else {
            res.status(404).send('student not found');
        }
        //res.send('Student Deleted');
    }
    catch (error) {
        console.log ("ERROR", error);
        res.status(500).sendStatus("Error Deleting students");
    }
});





module.exports = app;