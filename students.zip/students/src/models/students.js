const mongoose = require('mongoose');

const studentsSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    age: {
        type: Number,
        required: true,
    },
    sex: {
        type: String,
        require: true,
    },
    mark:{
        type: Number,
        require: true,
    },
    
    registeredOn: {
        type: Date,
        default: new Date(),
    },
});

const studentsModel = mongoose.model("studentsModel", studentsSchema);

module.exports = studentsModel;

